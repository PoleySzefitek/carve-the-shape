fx_version 'adamant'
game 'gta5'
lua54 'yes'
client_script 'cl.lua'
ui_page 'web/index.html'
files { 'web/index.html', 'web/main.css', 'web/main.js' }